#!/bin/sh

su challenge -c /bin/sh -c '/usr/bin/qemu-riscv64 /riscky'
